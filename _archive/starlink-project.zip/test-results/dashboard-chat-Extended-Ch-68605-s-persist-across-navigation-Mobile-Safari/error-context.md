# Page snapshot

```yaml
- button "Start App - Tap anywhere" [ref=e7] [cursor=pointer]:
  - img "Starlink Heart Welcome Screen" [ref=e8]
  - generic [ref=e9]: Start
```