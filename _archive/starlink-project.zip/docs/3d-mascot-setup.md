
## Premium Feature: 3D Mascot
To enable the 3D mascot:
1. Create a scene in Spline (https://spline.design)
2. Export as "Code" -> "React"
3. Copy the scene URL (e.g., https://prod.spline.design/...)
4. Paste it into `src/components/mascot/Starry3D.tsx` replacing `PASTE_YOUR_SPLINE_URL_HERE`
5. Enable "3D Mascot (Beta)" in app settings
