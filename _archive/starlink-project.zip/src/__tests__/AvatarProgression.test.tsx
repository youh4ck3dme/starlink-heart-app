
import { render, screen, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import StarlinkHeartApp from '../components/StarlinkHeartApp';
import { GamificationProvider } from '../features/gamification/context/GamificationContext';
import { createMemoryRouter, RouterProvider } from 'react-router-dom';
import * as GamificationContextModule from '../features/gamification/context/GamificationContext';

// Mock dependencies
vi.mock('../features/gamification/services/aiRewardEngine', () => ({
  generateDailyChallenges: vi.fn().mockResolvedValue([]),
  calculateRewards: vi.fn().mockResolvedValue({ xp: 0, gems: 0 }),
}));

// Setup router wrapper for StarlinkHeartApp
const renderAppWithLevel = (level: number) => {
    // Set gamification state in localStorage
    const state = {
        xp: 0,
        level: level,
        streakDays: 0,
        freezesLeft: 3,
        unlockedBadges: [],
        completedMissions: [],
        badges: [],
        availableMissions: [],
        isPremium: false
    };
    localStorage.setItem('starlink_gamification_v1', JSON.stringify(state));
    
    // Ensure hearts are empty to show intro text
    localStorage.setItem('starlink_hearts_v1', '[]');
    localStorage.setItem('hasStarted', 'true');

    const router = createMemoryRouter([
        {
            path: '/home',
            element: <StarlinkHeartApp />
        }
    ], {
        initialEntries: ['/home'],
    });

    return render(
        <GamificationProvider>
            <RouterProvider router={router} />
        </GamificationProvider>
    );
};

describe('Avatar Progression System', () => {

    beforeEach(() => {
        vi.clearAllMocks();
        localStorage.clear();
    });

    it('displays Robot avatar 🤖 for Level 1 (Beginner)', async () => {
        renderAppWithLevel(1);
        
        // Handle Welcome Screen
        const startBtn = screen.queryByRole('button', { name: /Start/i });
        if (startBtn) {
            startBtn.click();
            await waitFor(() => {
                expect(screen.queryByRole('button', { name: /Start/i })).not.toBeInTheDocument();
            }, { timeout: 3000 });
        }

        // Wait for Dashboard Header
        await waitFor(() => {
             // Look for Level 1 indicator in header
             expect(screen.getByText(/Lvl 1/)).toBeInTheDocument();
        });
        
        // Robot check - look for image with roboto src
        const avatars = screen.getAllByRole('img');
        const robotAvatar = avatars.find(img => (img as HTMLImageElement).src.includes('roboto'));
        expect(robotAvatar).toBeDefined();
    });

    it('displays Cometa avatar ☄️ for Level 6 (Intermediate)', async () => {
        renderAppWithLevel(6);
        
        const startBtn = screen.queryByRole('button', { name: /Start/i });
        if (startBtn) {
            startBtn.click();
            await waitFor(() => {
                expect(screen.queryByRole('button', { name: /Start/i })).not.toBeInTheDocument();
            }, { timeout: 3000 });
        }

        await waitFor(() => {
             expect(screen.getByText(/Lvl 6/)).toBeInTheDocument();
        });
        
        // Comet check
        const avatars = screen.getAllByRole('img');
        const cometAvatar = avatars.find(img => (img as HTMLImageElement).src.includes('cometa'));
        expect(cometAvatar).toBeDefined();
    });

    it('displays Starry avatar ⭐ for Level 11 (Advanced)', async () => {
        renderAppWithLevel(11);
        
        const startBtn = screen.queryByRole('button', { name: /Start/i });
        if (startBtn) {
            startBtn.click();
            await waitFor(() => {
                expect(screen.queryByRole('button', { name: /Start/i })).not.toBeInTheDocument();
            }, { timeout: 3000 });
        }

        await waitFor(() => {
             expect(screen.getByText(/Lvl 11/)).toBeInTheDocument();
        });
        
        // Starry check
        const avatars = screen.getAllByRole('img');
        const starryAvatar = avatars.find(img => (img as HTMLImageElement).src.includes('starry'));
        expect(starryAvatar).toBeDefined();
    });
});
